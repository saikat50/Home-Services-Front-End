/* ===================================================================
    
    Author          : Valid Template
    Template Name   : Edocom - Education & LMS Template
    Version         : 1.0
    
* ================================================================= */

(function($) {
    "use strict";

    $(document).on('ready', function() {

        /* ==================================================
            Countdown Init
         ===============================================*/
        loopcounter('counter-class');


    }); // end document ready function
})(jQuery); // End jQuery