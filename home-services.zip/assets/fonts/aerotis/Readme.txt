This font is a demo version font and does not contain all glyphs, and may only be used for personal use.
for the full version and license you can buy it at https://creativemarket.com/Ef_Studio/3739960-Belly-Betty-Script or https://fontbundles.net/ef-studio/252323-belly-betty/rel=LETU6V

Thank you